<?php
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (isset($_GET['id']) && isset($_GET['nombre']) && isset($_GET['email']) && isset($_GET['telefono']) && isset($_GET['asunto']) && isset($_GET['mensaje']) && isset($_GET['fecha'])) {
        $id = $_GET['id'];
        $nombre = $_GET['nombre'];
        $email = $_GET['email'];
        $telefono = $_GET['telefono'];
        $asunto = $_GET['asunto'];
        $mensaje = $_GET['mensaje'];
        $fecha = $_GET['fecha'];

    } else {
        echo "Error: Faltan parámetros en la URL.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="../css/mediaqueries.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <script src="https://cdn.tiny.cloud/1/ilwxm1jiw71bbiygsyjfvozomnb0s95r8qh5rs8i0egrpovw/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="../js/editor.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>

    <title>Respuesta de contacto</title>
</head>

<body>
    <section class="container about">
        <h2 class="subtitle">Respuesta de contacto</h2>
        <div class="form-container1">
            <div>
                <h2><?php echo $nombre; ?></h2>
                <div>
                    <p>
                        <b>Nº cliente: </b> <?php echo $id; ?><br>
                        <b>Email: </b><?php echo $email; ?><br>
                        <b>Teléfono: </b><?php echo $telefono; ?><br>
                        <b>Asunto: </b><?php echo $asunto; ?><br>
                        <b>Mensaje: </b><?php echo $mensaje; ?><br>
                        <b>Fecha: </b><?php echo $fecha; ?><br>
                    </p>
                </div>

                <h3 class="subtitle">Escribe tu respuesta:</h3>
                <form action="enviarRespuestaContacto.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="hidden" name="nombre" value="<?php echo $nombre; ?>">
                    <input type="hidden" name="email" value="<?php echo $email; ?>">
                    <input type="hidden" name="telefono" value="<?php echo $telefono; ?>">
                    <input type="hidden" name="asunto" value="<?php echo $asunto; ?>">
                    <input type="hidden" name="mensaje" value="<?php echo $mensaje; ?>">

                    <textarea name="respuesta" id="mytextarea" class="form__imput1" placeholder="Escribe tu respuesta al cliente"></textarea>
                    <br>
                    <input type="submit" class="form__submit" value="Enviar">
                </form>
            </div>
    </section>

</body>

</html>