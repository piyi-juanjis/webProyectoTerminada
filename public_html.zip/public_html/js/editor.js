

/*editor de texto de los mails de administracion*/

tinymce.init({
    selector: '#mytextarea'
  });




