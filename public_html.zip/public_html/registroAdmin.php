<?php

include("componentes/headerRegistro.php");
include("componentes/registroDeAdmin.php");
include("componentes/footer.php");

?>