<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="../css/mediaqueries.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>

    <title>Espacio interior</title>
</head>

<body>





    <main>




        <section class="container about">
            <h2 class="subtitle">Formularios de contacto</h2>
            <div class="form-container">
                <?php
                include("conexion.php");
                if (isset($_GET['eliminar'])) {
                    $id = $_GET['eliminar'];
                    $eliminar = "DELETE FROM formulario_contacto WHERE id = $id";
                    mysqli_query($conexion, $eliminar);
                }

                if ($conexion) {
                    $consulta = "SELECT * FROM formulario_contacto";
                    $resultado = mysqli_query($conexion, $consulta);
                    if ($resultado) {
                        while ($row = $resultado->fetch_array()) {
                            $id = $row['id'];
                            $nombre = $row['nombre'];
                            $email = $row['email'];
                            $telefono = $row['telefono'];
                            $asunto = $row['asunto'];
                            $mensaje = $row['mensaje'];
                            $fecha = $row['fecha'];
                ?>
                            <div>
                                <h2><?php echo $nombre; ?></h2>
                                <div>
                                    <p>
                                        <b>Nº cliente: </b> <?php echo $id; ?><br>
                                        <b>Email: </b><?php echo $email; ?><br>
                                        <b>Teléfono: </b><?php echo $telefono; ?><br>
                                        <b>Asunto: </b><?php echo $asunto; ?><br>
                                        <b>Mensaje: </b><?php echo $mensaje; ?><br>
                                        <b>Fecha: </b><?php echo $fecha; ?><br>
                                    </p>
                                </div>
                                <a class="ctaEliminar" href="?eliminar=<?php echo $id; ?>">Eliminar</a>
                                <a class="ctaResponder" href="contactoMail.php?id=<?php echo $id; ?>&nombre=<?php echo urlencode($nombre); ?>&email=<?php echo urlencode($email); ?>&telefono=<?php echo urlencode($telefono); ?>&asunto=<?php echo urlencode($asunto); ?>&mensaje=<?php echo urlencode($mensaje); ?>&fecha=<?php echo urlencode($fecha); ?>" class="btn btn-primary">Responder</a>

                            </div>
                <?php
                        }
                    }
                }
                ?>
            </div>
        </section>

    </main>


</body>

</html>