<?php

//include("inicioSesionAdministrador.php");
include("headerAdministrador.php");
include("guardar_blog.php");
include("tablaContactoAdministrador.php");
include("tablaGaleriaAdministrador.php");
include("tablaPresupuestoAdministrador.php");
include("footerAdministrador.php");

?>