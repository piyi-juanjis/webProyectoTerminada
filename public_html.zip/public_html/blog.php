<?php

include("componentes/headerBlog.php");
include("componentes/galeriaBlog.php");
include("componentes/footer.php");

?>