<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="../css/mediaqueries.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      tinymce.init({
        selector: '#mytextarea'
      });
    </script>
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>

    <title>Espacio interior</title>
</head>

<body>


    <main>








        <section class="formulario">
            <div class="container">
                <div class="container about">
                    <h2 class="subtitle">Artículos de la galería</h2>
                    <div class="form-container2">
                        <table class="estilo_tabla">
                            <tr>
                                <th>Título</th>
                                <th>Descripción</th>
                                <th>Imagen</th>
                                <th>Acciones</th>
                            </tr>
                            <?php
                            include("conexion.php");

                            // Consulta para obtener los artículos
                            $query = "SELECT * FROM guardar_blog ORDER BY fecha DESC";
                            $resultado = mysqli_query($conexion, $query);

                            // Iteración sobre los resultados de la consulta
                            while ($fila = mysqli_fetch_array($resultado)) {
                                $id = $fila["id"];
                                $titulo = $fila["titulo"];
                                $descripcion = $fila["mensaje"];
                                $imagen = $fila["imagen"];

                                // Ruta de la imagen
                                $rutaImagen = "../imagenes/img/" . basename($imagen);
                            ?>
                                <tr>
                                    <td class="estilo_celda"><?php echo $titulo; ?></td>
                                    <td class="estilo_celda"><?php echo $descripcion; ?></td>
                                    <td class="estilo_celda"><img src="<?php echo $rutaImagen; ?>" class="imagen_tabla"></td>
                                    <td class="estilo_celda"><a class="ctaEliminar" href="?eliminar=<?php echo $id; ?>">Eliminar</a></td>

                                </tr>
                            <?php
                            }

                            // Verificación de si se ha enviado el parámetro 'eliminar'
                            if (isset($_GET['eliminar'])) {
                                $idEliminar = $_GET['eliminar'];
                                // Eliminar el artículo de la base de datos
                                $eliminarQuery = "DELETE FROM guardar_blog WHERE id = $idEliminar";
                                mysqli_query($conexion, $eliminarQuery);
                            }

                            // Cierre de la conexión a la base de datos
                            mysqli_close($conexion);
                            ?>
                        </table>
                    </div>
                    <h2 class="subtitle">Insertar imágenes en la galería</h2>
                    <form enctype="multipart/form-data" class="form__imputs1" method="post" id="mi-formulario">

                        <p>
                            <label for="titulo" class="colocar_titulo">Título
                                <span class="obligatorio">*</span>
                            </label>
                            <input type="text" name="introducir_titulo" id="titulo" required="obligatorio" class="form__imput" placeholder="Título">
                        </p>

                        <p>
                            <label for="comentario" class="colocar_comentario">Mensaje
                                <span class="obligatorio">*</span>
                            </label>
                            <textarea name="introducir_comentario" class="form__imput1" id="comentario" required="obligatorio" placeholder="Deja aquí tu comentario..."></textarea>
                        </p>

                        <p>
                            <label for="foto_blog" class="colocar_foto_blog">Selecciona una imagen con tamaño inferior a 5mb
                                <span class="obligatorio">*</span>
                            </label>
                            <input type="file" name="introducir_foto_blog" id="foto_blog" required="obligatorio" class="" placeholder="Título">
                        </p>

                        <button type="submit" name="enviar_formulario" class="form__submit" id="enviar">
                            <p>Enviar</p>
                        </button>

                        <p class="aviso">
                            <span class="obligatorio"> * </span>los campos son obligatorios.
                        </p>

                    </form>
                </div>
        </section>



    </main>


</body>

</html>