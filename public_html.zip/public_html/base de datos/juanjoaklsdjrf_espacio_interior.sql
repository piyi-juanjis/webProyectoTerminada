-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 16-06-2023 a las 09:33:43
-- Versión del servidor: 10.3.39-MariaDB
-- Versión de PHP: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `juanjoaklsdjrf_espacio_interior`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulario_contacto`
--

CREATE TABLE `formulario_contacto` (
  `id` int(9) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` int(20) NOT NULL,
  `asunto` varchar(20) NOT NULL,
  `mensaje` varchar(200) NOT NULL,
  `fecha` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `formulario_contacto`
--

INSERT INTO `formulario_contacto` (`id`, `nombre`, `email`, `telefono`, `asunto`, `mensaje`, `fecha`) VALUES
(40, 'Juan', 'piyijuanjis@gmail.com', 123456789, 'Horario comercial', 'Buenas quisiera saber a q hora abrÃ­s los sÃ¡bados', '31/05/23'),
(45, 'juan', 'juanjose.s253004@cesurformacion.com', 123456, 'horario de apertura', 'queremos saber a q hora abrÃ­s?', '05/06/23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulario_presupuesto`
--

CREATE TABLE `formulario_presupuesto` (
  `id` int(9) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `catalogo` varchar(20) NOT NULL,
  `mensaje` varchar(200) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `formulario_presupuesto`
--

INSERT INTO `formulario_presupuesto` (`id`, `nombre`, `email`, `tipo`, `catalogo`, `mensaje`, `fecha`) VALUES
(9, 'Juan', 'piyijuanjis@gmail.com', 'viviendas', 'sillas', 'Estoy interesado en unas sillas para mi vivienda', '2031-05-23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `guardar_blog`
--

CREATE TABLE `guardar_blog` (
  `id` int(9) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `mensaje` varchar(500) NOT NULL,
  `imagen` varchar(500) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `guardar_blog`
--

INSERT INTO `guardar_blog` (`id`, `titulo`, `mensaje`, `imagen`, `fecha`) VALUES
(14, 'cocina', 'cocina moderna', '../imagenes/img/img6464c606624479.28345763.jpg', '2017-05-23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_pass`
--

CREATE TABLE `usuario_pass` (
  `ID` int(11) NOT NULL,
  `USUARIO` varchar(20) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuario_pass`
--

INSERT INTO `usuario_pass` (`ID`, `USUARIO`, `PASSWORD`) VALUES
(1, 'juan@juan.com', '1234');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `formulario_contacto`
--
ALTER TABLE `formulario_contacto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `formulario_presupuesto`
--
ALTER TABLE `formulario_presupuesto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `guardar_blog`
--
ALTER TABLE `guardar_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario_pass`
--
ALTER TABLE `usuario_pass`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `formulario_contacto`
--
ALTER TABLE `formulario_contacto`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de la tabla `formulario_presupuesto`
--
ALTER TABLE `formulario_presupuesto`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `guardar_blog`
--
ALTER TABLE `guardar_blog`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `usuario_pass`
--
ALTER TABLE `usuario_pass`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
