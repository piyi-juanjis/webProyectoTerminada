<?php
    session_start();
    if (!isset($_SESSION["introducir_email"])) {
        header("location:index.php");
    }
    ?>