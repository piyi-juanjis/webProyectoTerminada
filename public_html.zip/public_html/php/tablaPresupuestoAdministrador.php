<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="../css/mediaqueries.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>

    <title>Espacio interior</title>
</head>

<body>


    <section class="container about">
        <h2 class="subtitle">Formularios de presupuestos</h2>
        <div class="form-container1">
            <table class="estilo_tabla">
                <tr>
                    <th>Nº cliente</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Tipo</th>
                    <th>catálogo</th>
                    <th>Mensaje</th>
                    <th>Fecha</th>
                    <th></th>
                    <th></th>
                </tr>
                <?php
                include("conexion.php");
                if (isset($_GET['eliminar'])) {
                    $id = $_GET['eliminar'];
                    $eliminar = "DELETE FROM formulario_presupuesto WHERE id = $id";
                    mysqli_query($conexion, $eliminar);
                }

                if ($conexion) {
                    $consulta = "SELECT * FROM formulario_presupuesto";
                    $resultado = mysqli_query($conexion, $consulta);
                    if ($resultado) {
                        while ($row = $resultado->fetch_array()) {
                            $id = $row['id'];
                            $nombre = $row['nombre'];
                            $email = $row['email'];
                            $tipo = $row['tipo'];
                            $catalogo = $row['catalogo'];
                            $mensaje = $row['mensaje'];
                            $fecha = $row['fecha'];
                ?>
                            <tr>
                                <td class="estilo_celda"><?php echo $id; ?></td>
                                <td class="estilo_celda"><?php echo $nombre; ?></td>
                                <td class="estilo_celda"><?php echo $email; ?></td>
                                <td class="estilo_celda"><?php echo $tipo; ?></td>
                                <td class="estilo_celda"><?php echo $catalogo; ?></td>
                                <td class="estilo_celda"><?php echo $mensaje; ?></td>
                                <td class="estilo_celda"><?php echo $fecha; ?></td>
                                <td>
                                    <div class="botones">
                                        <a class="ctaEliminar" href="?eliminar=<?php echo $id; ?>">Eliminar</a>


                                        <a class="ctaResponder" href="presupuestoMail.php?id=<?php echo $id; ?>&nombre=<?php echo urlencode($nombre); ?>&email=<?php echo urlencode($email); ?>&tipo=<?php echo urlencode($tipo); ?>&catalogo=<?php echo urlencode($catalogo); ?>&mensaje=<?php echo urlencode($mensaje); ?>&fecha=<?php echo urlencode($fecha); ?>&precio=<?php echo urlencode($precio); ?>" class="btn btn-primary">Responder</a>



                                    </div>
                                </td>
                            </tr>
                <?php
                        }
                    }
                }
                ?>
            </table>
        </div>
    </section>

    </main>


</body>

</html>