<?php

include("componentes/header.php");
include("componentes/filosofia.php");
include("componentes/presupuesto.php");
include("componentes/servicios.php");
include("componentes/carrusel.php");
include("componentes/footer.php");

?>