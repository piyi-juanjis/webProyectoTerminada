<?php
$conexion = mysqli_connect("localhost", "juanjoaklsdjrf_juanjose", "lIjK)dnZq^S!", "juanjoaklsdjrf_espacio_interior");
?>
