<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (count($_POST) > 0) {
        $id = $_POST['id'];
        $respuesta = $_POST['respuesta'];

        $nombre = $_POST['nombre'];
        $email = $_POST['email'];
        $tipo = $_POST['tipo'];
        $catalogo = $_POST['catalogo'];
        $mensaje = $_POST['mensaje'];
        $fecha = $_POST['fecha'];

        // Configurar el correo electrónico
        $to = $email; // Dirección de correo electrónico del destinatario
        $subject = "Respuesta a tu presupuesto";
        $message = '<html><body>';
        $message .= '<img src="https://juanjo.extremovirtual.net/imagenes/logo.png" alt="Logo de la empresa">';
        $message .= '<br><br>';
        $message .= "Estimado/a $nombre,<br><br>Gracias por contactarnos. A continuación, le proporcionamos una respuesta a su mensaje: $mensaje<br><br>En referencia al tipo de decoración de $tipo del catálogo $catalogo, la respuesta es:<br><br>$respuesta<br><br>Un cordial saludo $nombre<br><br>";
        $message .= 'Visite nuestra página web: <a href="http://juanjo.extremovirtual.net">http://juanjo.extremovirtual.net</a>';
        $message .= '</body></html>';
        $headers = "From: juanjoaklsdjrf@juanjo.extremovirtual.net\r\n";
        $headers .= "Reply-To: juanjoaklsdjrf@juanjo.extremovirtual.net\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        // Enviar el correo electrónico
        if (mail($to, $subject, $message, $headers)) {
            echo "<script>window.location.href = 'administrador.php';</script>";
            //echo "La respuesta se envió correctamente por correo electrónico.";
        } else {
            echo "Hubo un problema al enviar la respuesta por correo electrónico.";
        }
    } else {
        echo "Error: Faltan parámetros en el formulario.";
    }
}
?>
